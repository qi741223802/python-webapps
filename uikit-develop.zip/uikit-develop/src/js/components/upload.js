function plugin(UIkit) {

    if (plugin.installed) {
        return;
    }

    var {addClass, ajax, matches, noop, on, removeClass, trigger} = UIkit.util;

    UIkit.component('upload', {

        props: {
            allow: String,
            clsDragover: String,
            concurrent: Number,
            mime: String,
            msgInvalidMime: String,
            msgInvalidName: String,
            multiple: Boolean,
            name: String,
            params: Object,
            type: String,
            url: String
        },

        defaults: {
            allow: false,
            clsDragover: 'uk-dragover',
            concurrent: 1,
            mime: false,
            msgInvalidMime: 'Invalid File Type: %s',
            msgInvalidName: 'Invalid File Name: %s',
            multiple: false,
            name: 'files[]',
            params: {},
            type: 'POST',
            url: '',
            abort: noop,
            beforeAll: noop,
            beforeSend: noop,
            complete: noop,
            completeAll: noop,
            error: noop,
            fail: noop,
            load: noop,
            loadEnd: noop,
            loadStart: noop,
            progress: noop
        },

        events: {

            change(e) {

                if (!matches(e.target, 'input[type="file"]')) {
                    return;
                }

                e.preventDefault();

                if (e.target.files) {
                    this.upload(e.target.files);
                }

                e.target.value = '';
            },

            drop(e) {
                stop(e);

                var transfer = e.dataTransfer;

                if (!transfer || !transfer.files) {
                    return;
                }

                removeClass(this.$el, this.clsDragover);

                this.upload(transfer.files);
            },

            dragenter(e) {
                stop(e);
            },

            dragover(e) {
                stop(e);
                addClass(this.$el, this.clsDragover);
            },

            dragleave(e) {
                stop(e);
                removeClass(this.$el, this.clsDragover);
            }

        },

        methods: {

            upload(files) {

                if (!files.length) {
                    return;
                }

                trigger(this.$el, 'upload', [files]);

                for (var i = 0; i < files.length; i++) {

                    if (this.allow) {
                        if (!match(this.allow, files[i].name)) {
                            this.fail(this.msgInvalidName.replace(/%s/, this.allow));
                            return;
                        }
                    }

                    if (this.mime) {
                        if (!match(this.mime, files[i].type)) {
                            this.fail(this.msgInvalidMime.replace(/%s/, this.mime));
                            return;
                        }
                    }

                }

                if (!this.multiple) {
                    files = [files[0]];
                }

                this.beforeAll(this, files);

                var chunks = chunk(files, this.concurrent),
                    upload = files => {

                        var data = new FormData();

                        files.forEach(file => data.append(this.name, file));

                        for (var key in this.params) {
                            data.append(key, this.params[key]);
                        }

                        ajax(this.url, {
                            data,
                            method: this.type,
                            beforeSend: env => {

                                var xhr = env.xhr;
                                xhr.upload && on(xhr.upload, 'progress', this.progress);
                                ['loadStart', 'load', 'loadEnd', 'abort'].forEach(type =>
                                    on(xhr, type.toLowerCase(), this[type])
                                );

                                this.beforeSend(env);

                            }
                        }).then(
                            xhr => {

                                this.complete(xhr);

                                if (chunks.length) {
                                    upload(chunks.shift());
                                } else {
                                    this.completeAll(xhr);
                                }

                            },
                            e => this.error(e.message)
                        );

                    };

                upload(chunks.shift());

            }

        }

    });

    function match(pattern, path) {
        return path.match(new RegExp(`^${pattern.replace(/\//g, '\\/').replace(/\*\*/g, '(\\/[^\\/]+)*').replace(/\*/g, '[^\\/]+').replace(/((?!\\))\?/g, '$1.')}$`, 'i'));
    }

    function chunk(files, size) {
        var chunks = [];
        for (var i = 0; i < files.length; i += size) {
            var chunk = [];
            for (var j = 0; j < size; j++) {
                chunk.push(files[i + j]);
            }
            chunks.push(chunk);
        }
        return chunks;
    }

    function stop(e) {
        e.preventDefault();
        e.stopPropagation();
    }

}

if (!BUNDLED && typeof window !== 'undefined' && window.UIkit) {
    window.UIkit.use(plugin);
}

export default plugin;
